﻿using BlazorApplication.Shared.Services;
using Microsoft.AspNetCore.Components;
using System;

namespace BlazorApplication.Shared.Components
{
    public class ComponentPlaceholderBase : ComponentBase, IDisposable
    {
        [Inject] ComponentManager Manager { get; set; }

        protected RenderFragment Content { get; set; }

        protected override void OnInit()
        {
            Manager.OnShow += Show;
            Manager.OnHide += Hide;
        }

        public void Show(RenderFragment content)
        {
            Content = content;
            StateHasChanged();
        }

        public void Hide()
        {
            Content = null;
            StateHasChanged();
        }

        public void Dispose()
        {
            Manager.OnShow -= Show;
            Manager.OnHide -= Hide;
        }
    }
}
