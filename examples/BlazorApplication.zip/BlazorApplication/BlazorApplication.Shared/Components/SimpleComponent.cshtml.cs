﻿using Microsoft.AspNetCore.Components;

namespace BlazorApplication.Shared.Components
{
    public class SimpleComponentBase : ComponentBase
    {
        public int CurrentCount { get; set; } = 0;

        public void Submit()
        {
            CurrentCount++;
        }
    }
}
