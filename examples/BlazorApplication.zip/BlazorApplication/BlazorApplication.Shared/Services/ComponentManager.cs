﻿using Microsoft.AspNetCore.Components;
using System;

namespace BlazorApplication.Shared.Services
{
    public class ComponentManager
    {
        public event Action<RenderFragment> OnShow;
        public event Action OnHide;

        public void Show(Type contentType)
        {
            if (!contentType.IsSubclassOf(typeof(ComponentBase)))
            {
                throw new ArgumentException($"{contentType.FullName} must be a Razor Component");
            }

            var content = new RenderFragment(x => { x.OpenComponent(1, contentType); x.CloseComponent(); });

            OnShow?.Invoke(content);
        }

        public void Hide()
        {
            OnHide?.Invoke();
        }
    }
}
