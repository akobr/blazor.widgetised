﻿using BlazorApplication.Shared.Services;
using Microsoft.Extensions.DependencyInjection;

namespace BlazorApplication.Shared.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddComponentManager(this IServiceCollection services)
        {
            return services.AddScoped<ComponentManager>();
        }
    }
}
