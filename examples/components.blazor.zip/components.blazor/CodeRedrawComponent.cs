﻿using System;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.RenderTree;

namespace components.blazor
{
    public class CodeRedrawComponent : ComponentBase, ITestableComponent
    {
        private ComponentState state = new ComponentState();
        private Action afterStateChange;
        private bool stateInChange = false;

        public Action AfterStateChange { set => afterStateChange = value; }

        public void ChangeState()
        {
            stateInChange = true;
            state = state.BuildNext();

            for (int i = 0; i < 10; i++)
            {
                StateHasChanged();
            }
        }

        protected override void BuildRenderTree(RenderTreeBuilder builder)
        {
            base.BuildRenderTree(builder);

            int sequence = 0;

            builder.OpenElement(sequence++, "h3");
            builder.AddAttribute(sequence++, "class", "company-header");
            builder.AddContent(sequence++, state.CompanyName);
            builder.CloseElement();

            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", "company-body");
            builder.OpenElement(sequence++, "a");
            builder.AddAttribute(sequence++, "href", state.CompanyWebsite);
            builder.AddContent(sequence++, state.CompanyWebsite);
            builder.CloseElement();
            builder.OpenElement(sequence++, "p");
            builder.AddContent(sequence++, state.CompanyDescription);
            builder.CloseElement();
            builder.CloseElement();

            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", "person");
            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", $"person-name {state.PersonNameClass}");
            builder.AddContent(sequence++, state.PersonName);
            builder.CloseElement();
            if (state.HasPersonEmail)
            {
                builder.OpenElement(sequence++, "div");
                builder.AddAttribute(sequence++, "class", "person-email");
                builder.AddContent(sequence++, state.PersonEmail);
                builder.CloseElement();
            }
            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", "person-description");
            builder.AddContent(sequence++, state.PersonDescription);
            builder.CloseElement();
            builder.CloseElement();
        }

        protected override void OnAfterRender()
        {
            if (!stateInChange)
            {
                return;
            }

            stateInChange = false;
            afterStateChange?.Invoke();
        }
    }
}
