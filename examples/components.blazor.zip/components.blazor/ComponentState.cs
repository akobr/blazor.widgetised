﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace components.blazor
{
    public class ComponentState
    {
        private const string RED_CLASS = "red";
        private const string BLUE_CLASS = "blue";

        public ComponentState()
            : this(null)
        {
            // no operation
        }

        private ComponentState(ComponentState basedOn)
        {
            CompanyName = RandomData.CompanyName;
            CompanyWebsite = RandomData.Website;
            CompanyDescription = RandomData.Paragraph;

            bool isFirstVariant = basedOn != null ? !basedOn.HasPersonEmail : true;

            PersonName = RandomData.FullName;
            PersonNameClass = isFirstVariant ? RED_CLASS : BLUE_CLASS;
            HasPersonEmail = isFirstVariant;
            PersonEmail = RandomData.Email;
            PersonDescription = RandomData.Paragraph;
        }

        public string CompanyName { get; }

        public string CompanyWebsite { get; }

        public string CompanyDescription { get; }

        public string PersonName { get; }

        public string PersonNameClass { get; }

        public bool HasPersonEmail { get; }

        public string PersonEmail { get; }

        public string PersonDescription { get; }

        public ComponentState BuildNext()
        {
            return new ComponentState(this);
        }
    }
}
