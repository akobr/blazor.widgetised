﻿using Microsoft.AspNetCore.Components;
using System;

namespace components.blazor
{
    public interface ITestableComponent : IComponent
    {
        Action AfterStateChange { set; }

        void ChangeState();
    }
}
