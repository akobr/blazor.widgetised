﻿using components.blazor.Shared;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.RenderTree;
using System.Diagnostics;

namespace components.blazor
{
    public class TestOfNativeComponents : PerformanceTest<RedrawComponent> { }

    public class TestOfInteropComponents : PerformanceTest<CodeInteropComponent> { }

    public class TestOfRedrawComponents : PerformanceTest<CodeRedrawComponent> { }

    public class PerformanceTest<TComponent> : ComponentBase
        where TComponent : ITestableComponent
    {
        private TComponent[] children;
        private Stopwatch watch = new Stopwatch();
        private ElementRef statsElement;
        private bool isInitialise = false;
        private int counter = 0;

        [Parameter]
        private int Count { get; set; }

        protected override void BuildRenderTree(RenderTreeBuilder builder)
        {
            base.BuildRenderTree(builder);

            isInitialise = true;
            int sequence = 0;
            children = new TComponent[Count];

            builder.OpenElement(sequence++, "p");
            builder.OpenElement(sequence++, "mark");
            builder.AddElementReferenceCapture(sequence++, (elemRef) => { statsElement = elemRef; });
            builder.AddContent(sequence++, $"Initial render of branchmark of {Count} {typeof(TComponent).Name} components.");
            builder.CloseElement();
            builder.CloseElement();

            for (int i = 0; i < Count; i++)
            {
                int index = i;

                builder.OpenComponent<TComponent>(sequence++);
                builder.AddComponentReferenceCapture(sequence++, (comRef) => 
                {
                    children[index] = (TComponent)comRef;
                    children[index].AfterStateChange = () => { if (++counter >= Count) FinishBrenchmark(); };
                });
                builder.CloseComponent();
            }
        }

        protected override bool ShouldRender()
        {
            return !isInitialise;
        }

        public void ProcessTest()
        {
            watch.Restart();
            counter = 0;

            foreach (TComponent component in children)
            {
                component.ChangeState();
            }
        }

        private void FinishBrenchmark()
        {
            watch.Stop();
            ElementInteropUtils.SetText(statsElement, $"Render of {Count} components in {watch.Elapsed}.");
        }
    }
}
