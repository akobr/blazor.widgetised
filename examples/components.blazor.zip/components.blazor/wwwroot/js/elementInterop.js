﻿window.elementInterop = {
    showElement: function (element) {
    element.classList.add('displayNone');
    },

    hideElement: function (element) {
        element.classList.remove('displayNone');
    },

    setText: function (element, text) {
        element.textContent = text;
    },

    getText: function (element) {
        return element.textContent;
    },

    addClassToElement: function (element, className) {
        element.classList.add(className);
    },

    removeClassToElement: function (element, className) {
        element.classList.remove(className);
    }
};

