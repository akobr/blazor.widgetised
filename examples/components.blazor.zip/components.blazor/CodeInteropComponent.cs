﻿using System;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.RenderTree;

namespace components.blazor
{
    public class CodeInteropComponent : ComponentBase, ITestableComponent
    {
        private ComponentState state = new ComponentState();
        private bool isInitialised = false;
        private Action afterStateChange;

        private ElementRef elementCompanyName;
        private ElementRef elementCompanyLink;
        private ElementRef elementCompanyDescription;
        private ElementRef elementPersonName;
        private ElementRef elementPersonEmail;
        private ElementRef elementPersonDescription;

        public Action AfterStateChange { set => afterStateChange = value; }

        public void ChangeState()
        {
            state = state.BuildNext();

            ElementInteropUtils.SetText(elementCompanyName, state.CompanyName);
            ElementInteropUtils.SetText(elementCompanyLink, state.CompanyWebsite);
            ElementInteropUtils.SetText(elementCompanyDescription, state.CompanyDescription);

            ElementInteropUtils.SetText(elementPersonName, state.PersonName);
            if (state.HasPersonEmail) { ElementInteropUtils.ShowElement(elementPersonEmail); }
            else { ElementInteropUtils.HideElement(elementPersonEmail); }
            ElementInteropUtils.SetText(elementPersonEmail, state.PersonEmail);
            ElementInteropUtils.SetText(elementPersonDescription, state.PersonDescription);

            afterStateChange?.Invoke();
        }

        protected override bool ShouldRender()
        {
            return !isInitialised;
        }

        protected override void BuildRenderTree(RenderTreeBuilder builder)
        {
            base.BuildRenderTree(builder);

            int sequence = 0;
            isInitialised = true;

            builder.OpenElement(sequence++, "h3");
            builder.AddAttribute(sequence++, "class", "company-header");
            builder.AddElementReferenceCapture(sequence++, (elRef) => elementCompanyName = elRef);
            builder.AddContent(sequence++, state.CompanyName);          
            builder.CloseElement();

            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", "company-body");
            builder.OpenElement(sequence++, "a");
            builder.AddAttribute(sequence++, "href", state.CompanyWebsite);
            builder.AddElementReferenceCapture(sequence++, (elRef) => elementCompanyLink = elRef);
            builder.AddContent(sequence++, state.CompanyWebsite);           
            builder.CloseElement();
            builder.OpenElement(sequence++, "p");
            builder.AddElementReferenceCapture(sequence++, (elRef) => elementCompanyDescription = elRef);
            builder.AddContent(sequence++, state.CompanyDescription);          
            builder.CloseElement();
            builder.CloseElement();

            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", "person");
            builder.OpenElement(sequence++, "div");
            builder.AddAttribute(sequence++, "class", $"person-name {state.PersonNameClass}");
            builder.AddElementReferenceCapture(sequence++, (elRef) => elementPersonName = elRef);
            builder.AddContent(sequence++, state.PersonName);
            builder.CloseElement();
            if (state.HasPersonEmail)
            {
                builder.OpenElement(sequence++, "div");                
                builder.AddAttribute(sequence++, "class", "person-email");
                builder.AddElementReferenceCapture(sequence++, (elRef) => elementPersonEmail = elRef);
                builder.AddContent(sequence++, state.PersonEmail);
                builder.CloseElement();
            }
            builder.OpenElement(sequence++, "div");           
            builder.AddAttribute(sequence++, "class", "person-description");
            builder.AddElementReferenceCapture(sequence++, (elRef) => elementPersonDescription = elRef);
            builder.AddContent(sequence++, state.PersonDescription);
            builder.CloseElement();
            builder.CloseElement();
        }
    }
}
