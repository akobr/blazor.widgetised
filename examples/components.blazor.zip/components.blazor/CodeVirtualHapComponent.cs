﻿using HtmlAgilityPack;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.RenderTree;
using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace components.blazor
{
    public class CodeVirtualHapComponent : ComponentBase, ITestableComponent
    {
        private const string template = "<h3 class=\"company-header\">[CompanyName]</h3><div class=\"company-body\"><a class=\"company-link\" href=\"#\">[CompanyLink]</a><p class=\"company-description\">[CompanyDescription]</p></div><div class=\"person\"><div class=\"person-name\">[PersonName]</div><div class=\"person-email\">[PersonEmail]</div><div class=\"person-description\">[PersonDescription]</div></div>";

        private ComponentState state = new ComponentState();
        private Action afterStateChange;
        private bool stateInChange = false;

        private HtmlDocument virtualDoc;
        private HtmlNode elementCompanyName;
        private HtmlNode elementCompanyLink;
        private HtmlNode elementCompanyDescription;
        private HtmlNode elementPersonName;
        private HtmlNode elementPersonEmail;
        private HtmlNode elementPersonDescription;

        public Action AfterStateChange { set => afterStateChange = value; }

        public void ChangeState()
        {
            stateInChange = true;
            state = state.BuildNext();

            SetCompanyName(state.CompanyName);
            SetCompanyLink(state.CompanyWebsite);
            SetCompanyDescription(state.CompanyDescription);

            SetPersonName(state.PersonName);
            SetPersonEmail(state.PersonEmail);
            SetPersonDescription(state.PersonDescription);

            StateHasChanged();
        }

        public void SetCompanyName(string text)
        {
            elementCompanyName.InnerHtml = text;
            //StateHasChanged();
        }

        public void SetCompanyLink(string text)
        {
            elementCompanyLink.SetAttributeValue("href", text);
            elementCompanyLink.InnerHtml = text;
            //StateHasChanged();
        }

        public void SetCompanyDescription(string text)
        {
            elementCompanyDescription.InnerHtml = text;
            //StateHasChanged();
        }

        public void SetPersonName(string text)
        {
            elementPersonName.InnerHtml = text;
            //StateHasChanged();
        }

        public void SetPersonEmail(string text)
        {
            elementPersonEmail.InnerHtml = text;
            //StateHasChanged();
        }

        public void SetPersonDescription(string text)
        {
            elementPersonDescription.InnerHtml = text;
            //StateHasChanged();
        }

        protected override void OnInit()
        {
            virtualDoc = new HtmlDocument();
            virtualDoc.LoadHtml(template);

            HtmlNode root = virtualDoc.DocumentNode;

            elementCompanyName = GetFirstElementByClassName(root, "company-header");
            elementCompanyLink = GetFirstElementByClassName(root, "company-link");
            elementCompanyDescription = GetFirstElementByClassName(root, "company-description");

            elementPersonName = GetFirstElementByClassName(root, "person-name");
            elementPersonEmail = GetFirstElementByClassName(root, "person-email");
            elementPersonDescription = GetFirstElementByClassName(root, "person-description");
        }

        protected override void BuildRenderTree(RenderTreeBuilder builder)
        {
            base.BuildRenderTree(builder);

            builder.OpenElement(0, "div");
            RenderVirtualDom(
                virtualDoc.DocumentNode,
                new RenderContext(builder, 1));
            builder.CloseElement();
        }

        protected override void OnAfterRender()
        {
            if (!stateInChange)
            {
                return;
            }

            stateInChange = false;
            afterStateChange?.Invoke();
        }

        private static void RenderNode(HtmlNode node, RenderContext context)
        {
            switch (node.NodeType)
            {
                case HtmlNodeType.Element:
                    {
                        RenderElement(node, context);
                        return;
                    }

                case HtmlNodeType.Text:
                    {
                        context.builder.AddContent(context.sequence++, node.InnerText);
                        return;
                    }
            }
        }

        private static void RenderVirtualDom(HtmlNode document, RenderContext context)
        {
            foreach (HtmlNode node in document.ChildNodes)
            {
                RenderNode(node, context);
            }
        }

        private static void RenderElement(HtmlNode element, RenderContext context)
        {
            context.builder.OpenElement(context.sequence++, element.Name);

            foreach (HtmlAttribute attribute in element.Attributes)
            {
                context.builder.AddAttribute(context.sequence++, attribute.Name, attribute.Value);
            }

            foreach (HtmlNode node in element.ChildNodes)
            {
                RenderNode(node, context);
            }

            context.builder.CloseElement();
        }

        private static HtmlNode GetFirstElementByClassName(HtmlNode target, string className)
        {
            Regex regex = new Regex("\\b" + Regex.Escape(className) + "\\b", RegexOptions.Compiled);

            return target.DescendantsAndSelf()
                .FirstOrDefault(n => n.NodeType == HtmlNodeType.Element && regex.IsMatch(n.GetAttributeValue("class", "")));
        }

        private class RenderContext
        {
            public RenderTreeBuilder builder;
            public int sequence;

            public RenderContext(RenderTreeBuilder builder, int sequence)
            {
                this.builder = builder;
                this.sequence = sequence;
            }
        }
    }
}
