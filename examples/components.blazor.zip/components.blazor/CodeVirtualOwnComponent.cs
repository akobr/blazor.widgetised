﻿using components.blazor.Virtual;
using HtmlAgilityPack;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.RenderTree;
using System;
using System.Linq;

namespace components.blazor
{
    public class CodeVirtualOwnComponent : ComponentBase, ITestableComponent
    {
        private const string template = "<h3 class=\"company-header\">[CompanyName]</h3><div class=\"company-body\"><a class=\"company-link\" href=\"#\">[CompanyLink]</a><p class=\"company-description\">[CompanyDescription]</p></div><div class=\"person\"><div class=\"person-name\">[PersonName]</div><div class=\"person-email\">[PersonEmail]</div><div class=\"person-description\">[PersonDescription]</div></div>";

        private ComponentState state = new ComponentState();
        private Action afterStateChange;
        private bool stateInChange = false;

        private ElementNode virtualDocRoot;
        private ElementNode elementCompanyName;
        private ElementNode elementCompanyLink;
        private ElementNode elementCompanyDescription;
        private ElementNode elementPersonName;
        private ElementNode elementPersonEmail;
        private ElementNode elementPersonDescription;

        public Action AfterStateChange { set => afterStateChange = value; }

        public void ChangeState()
        {
            stateInChange = true;
            state = state.BuildNext();

            SetCompanyName(state.CompanyName);
            SetCompanyLink(state.CompanyWebsite);
            SetCompanyDescription(state.CompanyDescription);

            if (state.HasPersonEmail)
            {
                elementPersonName.classes.Remove(ComponentState.BLUE_CLASS);
                elementPersonEmail.classes.Remove("displayNone");
            }
            else
            {
                elementPersonName.classes.Remove(ComponentState.RED_CLASS);                
                elementPersonEmail.classes.Add("displayNone");
            }
            elementPersonName.classes.Add(state.PersonNameClass);

            SetPersonName(state.PersonName);
            SetPersonEmail(state.PersonEmail);
            SetPersonDescription(state.PersonDescription);

            StateHasChanged();
        }

        public void SetCompanyName(string text)
        {
            elementCompanyName.SetText(text);
            //StateHasChanged();
        }

        public void SetCompanyLink(string text)
        {
            elementCompanyLink.attributes["href"] = text;
            elementCompanyLink.SetText(text);
            //StateHasChanged();
        }

        public void SetCompanyDescription(string text)
        {
            elementCompanyDescription.SetText(text);
            //StateHasChanged();
        }

        public void SetPersonName(string text)
        {
            elementPersonName.SetText(text);
            //StateHasChanged();
        }

        public void SetPersonEmail(string text)
        {
            elementPersonEmail.SetText(text);
            //StateHasChanged();
        }

        public void SetPersonDescription(string text)
        {
            elementPersonDescription.SetText(text);
            //StateHasChanged();
        }

        protected override void OnInit()
        {
            HtmlDocument virtualDoc = new HtmlDocument();
            virtualDoc.LoadHtml(template);
            virtualDocRoot = BuildVirtualDom(virtualDoc.DocumentNode);

            elementCompanyName = GetFirstElementByClassName(virtualDocRoot, "company-header");
            elementCompanyLink = GetFirstElementByClassName(virtualDocRoot, "company-link");
            elementCompanyDescription = GetFirstElementByClassName(virtualDocRoot, "company-description");

            elementPersonName = GetFirstElementByClassName(virtualDocRoot, "person-name");
            elementPersonEmail = GetFirstElementByClassName(virtualDocRoot, "person-email");
            elementPersonDescription = GetFirstElementByClassName(virtualDocRoot, "person-description");
        }

        protected override void BuildRenderTree(RenderTreeBuilder builder)
        {
            base.BuildRenderTree(builder);
            RenderElement(virtualDocRoot, new RenderContext(builder, 0));
        }

        protected override void OnAfterRender()
        {
            if (!stateInChange)
            {
                return;
            }

            stateInChange = false;
            afterStateChange?.Invoke();
        }

        private static void BuildNode(HtmlNode node, Node parent)
        {
            switch (node.NodeType)
            {
                case HtmlNodeType.Element:
                    {
                        BuildElement(node, parent);
                        return;
                    }

                case HtmlNodeType.Text:
                    {
                        parent.children.Add(new TextNode() { text = node.InnerText });
                        return;
                    }
            }
        }

        private ElementNode BuildVirtualDom(HtmlNode document)
        {
            ElementNode root = new ElementNode() { name = "div" };

            foreach (HtmlNode node in document.ChildNodes)
            {
                BuildNode(node, root);
            }

            return root;
        }

        private static void BuildElement(HtmlNode element, Node parent)
        {
            ElementNode vElement = new ElementNode() { name = element.Name };
            parent.children.Add(vElement);

            foreach (HtmlAttribute attribute in element.Attributes)
            {
                BuildAttribute(vElement, attribute);
            }

            foreach (HtmlNode node in element.ChildNodes)
            {
                BuildNode(node, vElement);
            }
        }

        private static void BuildAttribute(ElementNode vElement, HtmlAttribute attribute)
        {
            if (attribute.Name != "class")
            {
                vElement.attributes[attribute.Name] = attribute.Value;
                return;
            }

            foreach (string className in attribute.Value.Split(new[] { ' ', '\t', }, StringSplitOptions.RemoveEmptyEntries))
            {
                vElement.classes.Add(className);
            }
        }

        private static void RenderNode(Node node, RenderContext context)
        {
            if (node.isElement)
            {
                RenderElement((ElementNode)node, context);
            }
            else
            {
                context.builder.AddContent(context.sequence++, node.ToString());
            }
        }

        private static void RenderElement(ElementNode element, RenderContext context)
        {
            // Hind: way how to render events: UIEventArgsRenderTreeBuilderExtensions

            context.builder.OpenElement(context.sequence++, element.name);

            if (element.classes.Count > 0)
            {
                context.builder.AddAttribute(context.sequence++, "class", string.Join(" ", element.classes));
            }

            foreach (var attribute in element.attributes)
            {
                context.builder.AddAttribute(context.sequence++, attribute.Key, attribute.Value);
            }

            foreach (Node node in element.children)
            {
                RenderNode(node, context);
            }

            context.builder.CloseElement();
        }

        private static ElementNode GetFirstElementByClassName(ElementNode target, string className)
        {
            return (ElementNode)target.DescendantsAndSelf()
                .FirstOrDefault(n => n.isElement && ((ElementNode)n).classes.Contains(className));
        }

        private class RenderContext
        {
            public RenderTreeBuilder builder;
            public int sequence;

            public RenderContext(RenderTreeBuilder builder, int sequence)
            {
                this.builder = builder;
                this.sequence = sequence;
            }
        }
    }
}
