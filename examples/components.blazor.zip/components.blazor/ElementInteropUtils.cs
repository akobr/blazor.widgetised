﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System;
namespace components.blazor
{
    public static class ElementInteropUtils
    {
        public static void ShowElement(ElementRef element)
        {
            JSRuntime.Current.InvokeAsync<object>("elementInterop.showElement", element);
        }

        public static void HideElement(ElementRef element)
        {
            JSRuntime.Current.InvokeAsync<object>("elementInterop.hideElement", element);
        }

        public static void SetText(ElementRef element, string text)
        {
            if (text == null)
            {
                text = string.Empty;
            }

            JSRuntime.Current.InvokeAsync<object>("elementInterop.setText", element, text);
        }

        public static string GetText(ElementRef element)
        {
            return JSRuntime.Current.InvokeAsync<string>("elementInterop.getText", element).Result;
        }

        public static void AddClassToElement(ElementRef element, string className)
        {
            if (string.IsNullOrEmpty(className))
            {
                return;
            }

            JSRuntime.Current.InvokeAsync<string>("elementInterop.addClassFromElement", element, className);
        }

        public static void RemoveClassFromElement(ElementRef element, string className)
        {
            if (string.IsNullOrEmpty(className))
            {
                return;
            }

            JSRuntime.Current.InvokeAsync<string>("elementInterop.removeClassFromElement", element, className);
        }
    }
}
