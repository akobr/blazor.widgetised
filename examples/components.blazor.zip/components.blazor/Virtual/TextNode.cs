﻿namespace components.blazor.Virtual
{
    public class TextNode : Node
    {
        public string text;

        public override string ToString()
        {
            return text;
        }
    }
}
