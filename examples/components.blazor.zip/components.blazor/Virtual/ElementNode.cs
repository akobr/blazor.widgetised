﻿using System.Collections.Generic;

namespace components.blazor.Virtual
{
    public class ElementNode : Node
    {
        public string name;
        public readonly IDictionary<string, string> attributes = new Dictionary<string, string>(0);
        public readonly ISet<string> classes = new HashSet<string>();

        public ElementNode()
        {
            isElement = true;
        }

        public void SetText(string text)
        {
            if (children.Count == 1 && !children[0].isElement)
            {
                ((TextNode)children[0]).text = text;
                return;
            }

            children.Clear();
            children.Add(new TextNode { text = text });
        }
    }
}
