﻿using System.Collections.Generic;
using System.Linq;

namespace components.blazor.Virtual
{
    public class Node
    {
        public readonly IList<Node> children = new List<Node>(2);
        public bool isElement;

        public IEnumerable<Node> DescendantsAndSelf()
        {
            yield return this;

            foreach (Node node in Descendants())
            {
                yield return node;
            }
        }

        public IEnumerable<Node> Descendants()
        {
            foreach (Node child in children)
            {
                yield return child;
            }

            foreach (Node child in children.SelectMany(child => child.Descendants()))
            {
                yield return child;
            }
        }
    }
}
